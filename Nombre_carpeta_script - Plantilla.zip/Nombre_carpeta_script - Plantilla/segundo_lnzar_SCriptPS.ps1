$host.ui.RawUI.WindowTitle = �TItulodescriptel"  #tituloscript

Function LogWrite
{
    Param ([string]$logString)
	$outFile = $pathtemp + "\"+ $RootCauseID + "Nombredeficherolog.log"  # funcion crea el log aqui se establece el nombre del los
    $log = (Get-Date -format "dd/MM/yyyy; HH:mm:ss `t") 
	$log = $logString
    Add-content $outFile -value  $log 
}
$pathtemp = "\\IP_servidor\PATH_carpetas\Scripts\temp\temp\Nombre_carpeta_script"  #se gusrda en una variabel la ruta donde se ubica el script a ejecutar
 
notepad \\IP_servidor\PATH_carpetas\Scripts\temp\temp\Nombre_carpeta_script\notepad_con_lista_de_PCs.txt  #abre un notepad y aqui se pone la lista de los equipos que se quiere analizar 

Read-Host 'Pulsa Intro para continuar...' | Out-Null

$equipos=@()
$equipos = Get-Content \\IP_servidor\PATH_carpetas\Scripts\temp\temp\Nombre_carpeta_script\notepad_con_lista_de_PCs.txt   # aqui guarda el contenido del fichero en una variable

foreach($equipo in $equipos){
    Write-Host "Comprobando equipo $equipo..." -foregroundcolor "White"
    if(Test-Connection -ComputerName $equipo -Quiet -count 1){
        invoke-command -computername $equipo -scriptblock {   #aqui se lanza los comandos a consultar  sobre el equipo

        mkdir c:\temp\CertificadoscertificadoRaiz  ####
        netsh lan export profile folder=c:\temp\CertificadoscertificadoRaiz #####

        }     

	logWrite "$equipo;Activo" 
        Write-Host "$equipo;Activo" -foregroundcolor "Green"   #aqui se copa info en el log
        cmd /c copy /y "\\$equipo\C$\temp\mkdir_en_pc_revisado\Conexi?n de ?rea local.xml" \\IP_servidor\PATH_carpetas\Scripts\temp\temp\Nombre_carpeta_script\Logs\$equipo # aqui est� la carpeta logs
	cmd /c rmdir /s /q \\$equipo\C$\temp\mkdir_en_pc_revisado       #aqu� borra nuestra huella dentro de la carpeta
    }

    else{

        logWrite "$equipo;Inactivo"
        Write-Host "$equipo;Inactivo" -foregroundcolor "Red"

    }
   
}

Read-Host 'Pulsa Intro para continuar...' | Out-Null